package pageObjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class HomePage extends Base {

    @FindBy(className = "Logo_Logo___j29p")
    public WebElement logo;

}
