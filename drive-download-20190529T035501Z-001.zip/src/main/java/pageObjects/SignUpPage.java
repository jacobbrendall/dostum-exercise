package pageObjects;


public class SignUpPage extends Base {

}
