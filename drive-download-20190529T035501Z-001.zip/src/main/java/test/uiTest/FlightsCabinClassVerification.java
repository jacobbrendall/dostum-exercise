package test.uiTest;

import org.junit.Assert;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import pageObjects.Base;

import java.io.IOException;

public class FlightsCabinClassVerification extends Base {
    @DisplayName("TC-1006-1 Flights Page Business Class Should Displayed")
    @Test
    public void cabinBusinessClassShouldDisplayed() throws IOException {
        flightsPage.cabinClassVerifcation();
        Assert.assertTrue(flightsPage.getTravelersAndCabinButton().contains("Business"));
    }

}
